package test5;

import java.util.ArrayList;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;
import com.google.gson.GsonBuilder;

public class NoobChain {
	
	public static ArrayList<Block> blockchain = new ArrayList<Block>();
	public static int difficulty = 5;
	
	public static void main(String[] args) throws Exception {
		AESUtil se =new AESUtil();

		
		/*
         * ����
         */
		System.out.println("Block1:");
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforbe1234");
        System.out.println("���� StudentName:Bob Wilson");
        System.out.println("���ܺ��������:"+se.AESEncode("Bob", "iamakeyforbe1234"));
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforcd5678");
        System.out.println("����StudentPlan:Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming");
        System.out.println("���ܺ��������:"+se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforcd5678"));
        System.out.println("Block2:");
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforcd5678");
        System.out.println("����Course:Basis and Introduction of Information Technology");
        System.out.println("���ܺ��������:"+se.AESEncode("Basis and Introduction of Information Technology", "iamakeyforcd5678"));
        System.out.println("Block3:");
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforbe1234");
        System.out.println("����Course:Basis and Introduction of Information Technology, Information Processing and Practice");
        System.out.println("���ܺ��������:"+se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice", "iamakeyforbe1234"));
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforcd5678");
        System.out.println("����Badge:��Junior computer certificate��, CA: Shanghai University,2019/1/1");
        System.out.println("���ܺ��������:"+se.AESEncode("��Junior computer certificate��, CA: Shanghai University,2019/1/1", "iamakeyforbe1234"));
        System.out.println("Block4:");
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforbe1234");
        System.out.println("����Course:Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming");
        System.out.println("���ܺ��������:"+se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforbe1234"));
        System.out.println("ʹ��AES�ԳƼ��ܣ���Կ:iamakeyforcd5678");
        System.out.println("����Badge:��Junior Computer Application Certificate��, CA: Shanghai University,2019/1/1;��Intermediate Computer Application Certificate�� , CA: Shanghai University,2019/2/1");
        System.out.println("���ܺ��������:"+se.AESEncode("��Junior Computer Application Certificate��, CA: Shanghai University,2019/1/1;��Intermediate Computer Application Certificate�� , CA: Shanghai University,2019/2/1","iamakeyforcd5678"));
		System.out.println("");

		//��ʼ����Կ
        //������Կ��
        Map<String, Object> keyMap = RSACoder.initKey();
        //��Կ
        byte[] publicKey = RSACoder.getPublicKey(keyMap);

        //˽Կ
        byte[] privateKey = RSACoder.getPrivateKey(keyMap);
        System.out.println("��Կ��/n" + Base64.encodeBase64String(publicKey));
        System.out.println("˽Կ��/n" + Base64.encodeBase64String(privateKey));

        System.out.println("��Կ�Թ�����ϣ�");
        String str = "iamakeyforbe1234,iamakeyforcd5678";
        System.out.println("ԭ��:" + str);
        //�׷��������ݵļ���
        byte[] code1 = RSACoder.encryptByPrivateKey(str.getBytes(), privateKey);
        System.out.println("���ܺ�����ݣ�" + Base64.encodeBase64String(code1));
        
        //��ʼ����Կ
        //������Կ��
        Map<String, Object> keyMap1 = RSACoder1.initKey();
        //��Կ
        byte[] publicKey1 = RSACoder1.getPublicKey(keyMap1);

        //˽Կ
        byte[] privateKey1 = RSACoder1.getPrivateKey(keyMap1);
        System.out.println("��Կ��/n" + Base64.encodeBase64String(publicKey1));
        System.out.println("˽Կ��/n" + Base64.encodeBase64String(privateKey1));

        System.out.println("��Կ�Թ�����ϣ�");
        String str1 = "iamakeyforbe1234";
        System.out.println("ԭ��:" + str1);
        //�׷��������ݵļ���
        byte[] code2 = RSACoder1.encryptByPrivateKey(str1.getBytes(), privateKey);
        System.out.println("���ܺ�����ݣ�" + Base64.encodeBase64String(code2));
        System.out.println("");
        //add our blocks to the blockchain ArrayList:
		
		System.out.println("Trying to Mine block 1... ");
		addBlock(new Block("B123",se.AESEncode("Bob Wilson", "iamakeyforbe1234"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforcd5678"),
				null,
				null,"0"));
		
		System.out.println("Trying to Mine block 2... ");
		addBlock(new Block("B123",se.AESEncode("Bob Wilson", "iamakeyforbe1234"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforcd5678"),
				se.AESEncode("Basis and Introduction of Information Technology", "iamakeyforcd1234"),
				null,blockchain.get(blockchain.size()-1).hash));
		
		System.out.println("Trying to Mine block 3... ");
		addBlock(new Block("B123",se.AESEncode("Bob Wilson", "iamakeyforbe1234"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforcd5678"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice", "iamakeyforcd1234"),
				se.AESEncode("��Junior computer certificate��, CA: Shanghai University,2019/1/1", "iamakeyforbe5678"),blockchain.get(blockchain.size()-1).hash));
		System.out.println("Trying to Mine block 4... ");
		addBlock(new Block("B123",se.AESEncode("Bob Wilson", "iamakeyforbe1234"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforcd5678"),
				se.AESEncode("Basis and Introduction of Information Technology, Information Processing and Practice, Advanced Programming", "iamakeyforbe1234"),
				se.AESEncode("��Junior Computer Application Certificate��, CA: Shanghai University,2019/1/1;��Intermediate Computer Application Certificate�� , CA: Shanghai University,2019/2/1", "iamakeyforcd5678"),blockchain.get(blockchain.size()-1).hash));
		System.out.println("\nBlockchain is Valid: " + isChainValid());
		
		String blockchainJson = StringUtil.getJson(blockchain);
		System.out.println("\nThe block chain: ");
		System.out.println(blockchainJson);

    }
       
	
	public static Boolean isChainValid() {
		Block currentBlock; 
		Block previousBlock;
		String hashTarget = new String(new char[difficulty]).replace('\0', '0');
		
		//loop through blockchain to check hashes:
		for(int i=1; i < blockchain.size(); i++) {
			currentBlock = blockchain.get(i);
			previousBlock = blockchain.get(i-1);
			//compare registered hash and calculated hash:
			if(!currentBlock.hash.equals(currentBlock.calculateHash()) ){
				System.out.println("Current Hashes not equal");			
				return false;
			}
			//compare previous hash and registered previous hash
			if(!previousBlock.hash.equals(currentBlock.previousHash) ) {
				System.out.println("Previous Hashes not equal");
				return false;
			}
			//check if hash is solved
			if(!currentBlock.hash.substring( 0, difficulty).equals(hashTarget)) {
				System.out.println("This block hasn't been mined");
				return false;
			}
			
		}
		return true;
	}
	
	public static void addBlock(Block newBlock) {
		newBlock.mineBlock(difficulty);
		blockchain.add(newBlock);
	}
}

