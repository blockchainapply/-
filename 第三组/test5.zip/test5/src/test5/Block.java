package test5;

import java.util.Date;

public class Block {
	
	public String hash;
	public String previousHash; 
	private String UserName; //our data will be a simple message.
	private long timeStamp; //as number of milliseconds since 1/1/1970.
	private int nonce;
	private String StudentName;
	private String StudyPlan;
	private String Course;
	private String Badge;
	//Block Constructor.  
	public Block(String UserName,String StudentName,String StudyPlan,String Course,String Badge,String previousHash ) {
		this.UserName = UserName;
		this.StudentName = StudentName;
		this.StudyPlan = StudyPlan;
		this.Course = Course;
		this.Badge = Badge;
		this.previousHash = previousHash;
		this.timeStamp = new Date().getTime();
		
		this.hash = calculateHash(); //Making sure we do this after we set the other values.
	}
	
	//Calculate new hash based on blocks contents
	public String calculateHash() {
		String calculatedhash = StringUtil.applySha256( 
				previousHash +
				Long.toString(timeStamp) +
				Integer.toString(nonce) 

				);
		return calculatedhash;
	}
	
	//Increases nonce value until hash target is reached.
	public void mineBlock(int difficulty) {
		String target = StringUtil.getDificultyString(difficulty); //Create a string with difficulty * "0" 
		while(!hash.substring( 0, difficulty).equals(target)) {
			nonce ++;
			hash = calculateHash();
		}
		System.out.println("Block Mined!!! : " + hash);
	}
	
}